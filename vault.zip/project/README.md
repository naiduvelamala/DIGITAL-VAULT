# Digital Vault - Secure Time Capsule Platform

A decentralized platform for storing encrypted files with time-lock and geo-lock access controls using Aptos blockchain and Move smart contracts.

## 🚀 Features

- **Time-Locked Capsules**: Files unlock automatically at specified dates/times
- **Geo-Locked Capsules**: Location-restricted access using GPS coordinates
- **Military-Grade Security**: AES-256 encryption with blockchain-based access control
- **IPFS Storage**: Decentralized file storage with content addressing
- **Petra Wallet Integration**: Secure authentication and transaction signing
- **Professional UI**: Dark navy blue military-inspired interface

## 🏗️ Architecture

### Frontend (React)
- Modern React application with hooks and context
- Aptos SDK integration for blockchain interactions
- Client-side encryption/decryption
- Responsive design with professional military theme

### Smart Contracts (Move)
- Time-locked capsule creation and unlocking
- Geo-locked capsule with location verification
- Access control and ownership management
- Event emission for audit trails

### Storage
- IPFS for encrypted file storage
- Blockchain for metadata and access rules
- Client-side key management

## 📋 Prerequisites

- Node.js 18+ and npm
- Petra Wallet browser extension
- Aptos CLI (for smart contract deployment)

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd digital-vault
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

## 🔧 Smart Contract Deployment

1. **Install Aptos CLI**
   ```bash
   curl -fsSL "https://aptos.dev/scripts/install_cli.py" | python3
   ```

2. **Initialize Aptos account**
   ```bash
   aptos init
   ```

3. **Compile contracts**
   ```bash
   cd move-contracts
   aptos move compile
   ```

4. **Deploy to testnet**
   ```bash
   aptos move publish --named-addresses digital_vault=<your-address>
   ```

5. **Update contract address**
   - Copy deployed contract address
   - Update `SMART_CONTRACT_ADDRESS` in `src/services/aptosService.js`

## 🎯 Use Cases

### Case Study: Army Base Operations

**Scenario**: Classified documents should only be accessible:
- Inside specific Army Base (Geo-Lock)
- After mission start time (Time-Lock)

**Process**:
1. Officer uploads classified PDF via frontend
2. File encrypted → stored on IPFS → returns CID
3. Smart contract stores CID + access rules on Aptos blockchain
4. Officer requests access with Petra wallet + GPS proof
5. Smart contract verifies time and location constraints
6. If authorized → releases decryption key
7. File downloaded from IPFS → decrypted locally

## 🔐 Security Features

- **AES-256 Encryption**: Military-grade file encryption
- **Blockchain Verification**: Tamper-proof access control
- **Zero-Knowledge Architecture**: Complete privacy protection
- **Audit Trail**: All access events recorded on blockchain
- **Multi-Factor Authentication**: Time + Location + Wallet signature

## 🌐 API Integration

### Geolocation Services
- GPS coordinate detection
- Military base location database
- Distance calculation and verification

### IPFS Integration
- Encrypted file upload/download
- Content addressing and integrity verification
- Decentralized storage with redundancy

### Aptos Blockchain
- Smart contract interaction
- Transaction signing and verification
- Event monitoring and audit logs

## 📱 User Interface

### Design System
- **Colors**: Navy blue (#0F172A) with cyan accents (#06B6D4)
- **Typography**: Inter font family with proper hierarchy
- **Components**: Glass morphism effects with subtle animations
- **Layout**: Responsive grid system with mobile-first approach

### Key Screens
- **Wallet Connection**: Secure Petra wallet integration
- **Dashboard**: Capsule overview with status indicators
- **Create Capsule**: File upload with access control configuration
- **Location Status**: Real-time GPS tracking and verification

## 🔄 Development Workflow

1. **Frontend Development**
   ```bash
   npm run dev          # Start development server
   npm run build        # Build for production
   npm run preview      # Preview production build
   ```

2. **Smart Contract Development**
   ```bash
   aptos move test      # Run Move unit tests
   aptos move compile   # Compile contracts
   aptos move publish   # Deploy to blockchain
   ```

3. **Testing**
   - Unit tests for Move contracts
   - Integration tests for frontend
   - End-to-end testing with testnet

## 🚀 Deployment

### Frontend Deployment
- Build optimized production bundle
- Deploy to CDN or static hosting
- Configure environment variables

### Smart Contract Deployment
- Deploy to Aptos testnet for testing
- Deploy to Aptos mainnet for production
- Verify contract source code

## 📊 Monitoring

- Transaction monitoring on Aptos Explorer
- IPFS pin status and availability
- User activity and capsule statistics
- Error tracking and performance metrics

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Join our Discord community
- Check documentation wiki

---

**⚠️ Security Notice**: This platform handles sensitive data. Always verify smart contract addresses and use hardware wallets for production deployments.